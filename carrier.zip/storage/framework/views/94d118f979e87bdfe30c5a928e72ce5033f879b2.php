<?php $__env->startSection('content'); ?>
<style>
*{
   padding:0;
}
body{
    margin:0;
    padding:0;
    background:white;
}
aside{
  padding-left:7% !important;
  padding-right:7% !important;
}
 .bg-purple {
    background: linear-gradient(to bottom, #660066 0%, #660066 100%);}
 .billboard{
    background-size:100% contain;
    height:90vh;

}
nav > img{
  height: 140px;
  width: 75%;
}




.text-dark{
  color:black !important;
}
a, a:hover{
  text-decoration: none !important;
}

@media  screen and (max-width: 480px) {
  #side_img {display:none !important;}
  .display-4{font-size:2.5em;}
  aside{
  padding-left:3% !important;
  padding-right:3% !important;
}
nav > img{
  height: 100px;
  width: 75%;
}
h5{
  font-size:.9em;
}
.h5{
  font-size:1.2em;
}

}
</style>

<div class="container-fluid billboard p-lg-3 px-lg-5 bg-white" style="">

<br><br><br><br><br>

<div class="row">
<div class="col-lg-6">
<div class="container pl-lg-5">
<h1 class="text-dark display-4 font-weight-bolder">The Most Reliable Online Autoshop</h1>
<h6 class="text-dark ml-lg-1">Get Your Automobile Fixed . Anywhere . Anytime </h6>
<br><br>
<?php if(auth()->guard()->guest()): ?>
<a href="<?php echo e(route('register')); ?>" class="btn rounded-lg ml-lg-3 bg-darkpurple shadow px-4"><span class="text-light"> Get started </span></a>
<br><br><br>
<?php endif; ?>
<div class="container ml-lg-3" style="border-left:1px solid blue">
<p class="text-secondary small">
QwikMech is focused on providing Car repairs and maintenance services in Nigeria. You don’t have to worry if your car breaks down in an unexpected place, 
with QwikMech you can just book for a trusted and tested Mechanic near you,  to come to your aid.

</p>
</div>
</div>

</div>
<div class="col-lg-6">


<div class="container-fluid d-md-none d-lg-block d-none" style="" id="side_img">
<img src="<?php echo e(asset('/images/users/main_image.png')); ?>" class="img-fluid rounded-lg pr-lg-4 mr-lg-4" width="100%">
</div>

</div>
</div>
</div>


<aside class="jumbotron bg-light mb-0">
<h1 class="font-weight-bolder ml-lg-5 text-center">Our Options</h1>
<h6 class="small text-secondary px-lg-5 px-1 text-center">With QwikMech you don’t worry about mechanics 
  extorting  from you by either over pricing car parts prices or the services they rendered you.</h6>
<br><br>
<div class="row px-lg-1">


<div class="col-lg-4 col-md-6 px-4 mb-4">
<a href="<?php echo e(route('category.dealers')); ?>">
<div class="container p-4 bg-white rounded">
  <div class="row">
    <div class="col-12">
      <img src="img/dealer.svg" class="img-fluid mb-2 rounded-lg pr-lg-4 mr-lg-4" width="80%">
    </div>
    <div class="col-12">
      <h4 class="text-dark">Vends</h4>
      <p class="text-secondary">
    With QwikMech we connect you directly with trusted car parts vendors for both new and used(toks), you pay directly to us assuring you that you’d get the best price for any part you purchase through our platform.
      </p></div>
  </div>


</div>
</a>
</div>

<div class="col-lg-4 col-md-6 px-4 mb-4">
<a href="<?php echo e(route('category.mechanics')); ?>">
<div class="container p-4 bg-white rounded">
  <div class="row">
    <div class="col-12">
      <img src="img/mechanic.svg" class="img-fluid mb-2 rounded-lg pr-lg-4 mr-lg-4" width="50%">
    </div>
    <div class="col-12">
      <h4 class="text-dark">Mechs</h4>
      <p class="text-secondary">
        With QwikMech you can now order for a mechanic service same way you order for a cab service using Uber or Bolt.
        With your location on our App detects your exact location and connects with you the closet and available mechanic.
      
      </p></div>
  </div>


</div>
</a>
</div>


<div class="col-lg-4 col-md-6 px-4 mb-4">
  <a href="<?php echo e(route('category.carparts')); ?>">
  <div class="container p-4 bg-white rounded">
   <div class="row">
     <div class="col-12"> <img src="img/autoshop.svg" class="img-fluid mb-2 rounded-lg pr-lg-4 mr-lg-4" width="100%"></div>
     <div class="col-12"> <h4 class="text-dark">Autoshop</h4>
      <p class="text-secondary">
        For those who prefer using auto workshops you’re not left out, QwikMech would serve as a directory to the best Auto work shops around you.
      
      </p>
    </div>
   </div> 
 
 
  </div>
  </a>
  </div>

</div>
</aside>

<aside class="jumbotron bg-warning mt-0 px-3 p-lg-5">
  <br>
<center><h1 class="font-weight-bolder">Our Services</h1>
<h6 class="small text-dark">You pay directly  for any service on our platform as well as  ordering any car part from us thereby saving you the stress and extortion from today’s mechanics</h6></center>

<br>

<div class="container px-3 mb-4">
  
  <div class="container p-4 rounded">
  <div class="row">
    <div class="col-12 col-lg-6"><img src="img/business.png" class="img-fluid mb-2 rounded-lg pr-lg-4 mr-lg-5" width="100%"></div>
    <div class="col-12 col-lg-6">
      <h4 class="text-dark">Info</h4>
      <p class="text-dark">
        Book a Mechanic close to you  from any location, order for any car part and get it delivered to your doorstep at very competitive rates. This and anything you need to keep your car performing in the best condition is all we want to achieve with QwikMech. Our services in Nigeria includes attending to emergency car break down situation, towing, car engine maintenance, car brakes service, car true service, car Ac service, car panel beating service, car denting and painting,
        battery services etc. literally anything you need to get your car fixed and on the go</p>
    </div>
  </div>
  
 
  </div>
  
  </div>

</aside>

<aside class="container px-3 p-lg-5" >
<hr>
<a href="<?php echo e(route('category.carparts')); ?>"><h1 class="font-weight-lighter text-dark">Car parts</h1></a>
<h6 class="small text-secondary">Buy authentic car parts at cheap rates</h6>
<br><br>
<div class="row">
 <?php $__currentLoopData = $carparts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $carpart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-6 col-lg-3 mb-3">
  <form method="POST" action="<?php echo e(route('carpart.details')); ?>">
     <?php echo csrf_field(); ?>
   <input type="hidden" name="car_id" value="<?php echo e($carpart->car_id); ?>">
   <button type="submit" style="background:transparent;border:transparent;<?php echo e(asset('/images/carparts/'.$carpart->car_image)); ?>">
  <div class="container border py-4 px-0 b-3" style="border-radius:20px">
    <center>
    <img src="<?php echo e(asset('/images/carparts/'.$carpart->car_image)); ?>" style="border-radius:20px" class="img-fluid" width="70%">
    </center>
   
    <div class="container">
    <hr>
    <center>
    <h6 class="font-weight-bold text-secondary text-left"><?php echo e($carpart->part_name); ?></h6>

    <h5 class="font-weight-bold text-dark text-left h5" style="color:orangered"><span class="text-danger">N</span> <?php echo e($carpart->price); ?></h5>
    </center>
    </div>
    

  </div>
  </button>
  </form>
</div>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



</div>  
</aside>





<aside class="container p-lg-4" >
<hr>
<a href="<?php echo e(route('category.dealers')); ?>"><h1 class="font-weight-lighter text-dark">Vends</h1></a>
<h6 class="small text-secondary">Our Vendors bring quality material to the table.</h6>
<br><br>
<div class="row">
 <?php $__currentLoopData = $dealers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-6 col-md-6 col-lg-3 mb-3">
  <a href="/category/dealers/<?php echo e($user->d_id); ?>">
  <div class="container border py-3 px-0" style="border-radius:20px">
    <center>
   <?php if($user->image_path == ""): ?>
   <br>
     <img src="<?php echo e(asset('/images/dealers/'.$user->image_path)); ?>" class="shadow" style="border-radius:20px" height="140px" width="75%">
  
     <?php else: ?>
     
         <br>
         <nav>
        <img src="<?php echo e(asset('/images/dealers/'.$user->image_path)); ?>" class="fluid" style="border-radius:20px" />
         </nav>
     <?php endif; ?>
    
    </center>

   
 <div class="container font-weight-bold text-center">
 <hr>
 <h5 class="font-weight-bold text-dark"><?php echo e($user->dealer_type); ?></h5>
 </div>

  </div>
  </a>
</div>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



</div>  
</aside>



<aside class="container p-lg-4" >
<hr>
<a href="<?php echo e(route('category.mechanics')); ?>"><h1 class="font-weight-lighter text-dark">Mechanics</h1></a>
<h6 class="small text-secondary">Quality technicians at the go</h6>
<br><br>
<div class="row">
 <?php $__currentLoopData = $mechanics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-6 col-md-6 col-lg-3 mb-3">
 <a href="/category/mechanics/<?php echo e($user->m_id); ?>">
  <div class="container border py-3 px-0" style="border-radius:20px">
    <center>
   <?php if($user->image_path == ""): ?>
   <br>
     <img src="<?php echo e(asset('/images/mechs/'.$user->image_path)); ?>" class="shadow" style="border-radius:20px" height="100px" width="75%">
  
     <?php else: ?>
     
         <br>
         <nav>
        <img src="<?php echo e(asset('/images/mechs/'.$user->image_path)); ?>" class="fluid" style="border-radius:20px" >
         </nav>
     <?php endif; ?>
  

  <div class="container font-weight-bold text-center">
 <hr>
 <h5 class="font-weight-bold text-dark"><?php echo e($user->mechanic_type); ?></h5>
 </div>

    </center>

  </div>
  </a>
</div>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



</div>  
</aside>

<br><br><br>
<script>
sessionStorage.clickcount = 1;
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\carrier\resources\views/welcome.blade.php ENDPATH**/ ?>