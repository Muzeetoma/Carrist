@extends('layouts.app')


@section('content')
<div class="jumbotron">
<center>
<span class="la la-check text-success" style="font-size:120px"></span>
<h3>Your account has been verified successfully</h3>

</center>

</div>
<div class="container">
<center>
<a href="/" class="btn btn-primary rounded-lg mt-5 px-5">Continue <span class="la la-arrow-right"></span></a>

</center>
</div>

@endsection